# Build provenance

Methodology and claim extraction: InSites-Lab/insites, specification 11.5 modules and claim-extractor codebook 1.1, Apache-2.0. Original analytical rules are assembled as text. Integration passages for rendering, conversation delivery, file output and model-specific usage suggestions are adapted during this build. The original repository files are not edited. Divider modules are not instruction files. No heritage source document or research transcript is bundled. See BUILD-MANIFEST.json for exact source hashes.
