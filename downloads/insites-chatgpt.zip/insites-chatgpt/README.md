# InSites ChatGPT plugin

Early development version, not yet for use in formal assessments. Skills are built from specification 11.5 modules. Connect the stateless InSites MCP server as an app in the intended workspace. Start with the connection-test skill. This package contains no data, server credentials or assessment sources.
