# InSites

Early development version, not yet for use in formal assessments. Use non-confidential trial material.

Import the complete package with Plugin Creator and select Install plugin. In a new ChatGPT Desktop Work conversation, select @InSites, upload or paste a short text of your choice, and write "Begin assessment." Review each stage before continuing.

The delivery ZIP includes INSTALL.md with the installation steps. Connection diagnostics are available on explicit request.
