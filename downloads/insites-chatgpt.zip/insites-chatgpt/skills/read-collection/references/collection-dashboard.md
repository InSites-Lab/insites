## [CA-DB-C] Collection Dashboard — MA-RC Integration

> **Scope**: Collection-level visualization (multiple sites from MA-RC analysis). For single-assessment dashboards (one site, one CBSA process), see [CA-DB] above. Both share the UX foundation ([CA-DB-F]) but have different data shapes, tab structures, and visual palettes. Collection: Inter + stone/amber palette.
>
> **Visual reference**: Visual tokens and entity categories are documented in the bundled runtime contract.

### 1. Trigger and Offer

- Offer after at least one MA-RC Step 3 analysis: "Would you like a visual dashboard for this collection?"
- Also generate on direct request ("dashboard", "collection dashboard", "visualize").
- Execute only on acceptance — do not auto-generate.
- Call the rendering tool; no surrounding prose on success. Explain failures in chat.
- **Format**: call `render_insites` with approved DATA. The MCP App owns rendering and conversation delivery.

### 2. Data Projection

Re-read the approved MA-RC Step 2 extraction output and any approved Step 3 analyses, then project them into per-site JSON records. This changes representation only. The dashboard layer does not extract a new finding, classify a field, infer an absence, or compose a new collection insight.

| Step 2 field | Dashboard field(s) | Notes |
|---|---|---|
| Name | `name` | Short display name |
| Location | `location`, `region`, `lat`, `lng`, `coordinateSource` | Copy approved location fields and coordinates; use null when coordinates were not resolved upstream |
| Type | `type`, `mappedTypeCategory` | Preserve the exact source/output term; optional mapping only if already approved or explicitly requested |
| Period | `period`, `mappedPeriodCategory` | Preserve the exact source/output term; optional mapping only if already approved or explicitly requested |
| Site description | `description` | 1–2 sentences |
| Significance summary | `significanceSummary`, `highlight` | Copy the approved significance summary. `highlight` is optional and may only reuse an approved site-level collection insight; do not write one in the dashboard layer |
| Values identified | `values: { [exactValueLabel]: "e"/"i"/"a"/"u" }` | Dynamic open vocabulary from the approved outputs. `e` = explicit; `i` = upstream classified as implied; `a` = upstream explicitly found absent; `u` = not stated/unknown. Never turn silence into `a` |
| Integrity / Authenticity | `integrity`, `integrityNote`, `mappedIntegrityLevel` | Preserve the approved wording; an optional normalized level appears only if already produced/requested |
| Threats | `threats[]` | Exact approved threat labels/IDs; optional mappings remain separate |
| Assessment method | `method`, `mappedMethodType` | Preserve the approved method name; optional mapping only if already produced/requested |
| Comparative references | `comparativeBasis`, `mappedClaimScope` | Preserve the approved comparison and scope wording; optional mapping only if already produced/requested |

Also project from the approved Collection Reading and Step 3 analyses, when present:
- `significancePremises[]` — copy approved premises and their original labels; do not assign premises in the dashboard layer.
- `managementClusters[]` — copy approved grouping labels and membership from a completed analysis.
- `themes[]` — optional. Copy approved theme objects and memberships: `{ id, label, description, sites: [siteId], evidence: { siteId: "text" } }`. Do not generate a minimum theme or group sites while preparing `DATA`.
- `tabs[]` — copy approved MA-RC Step 3 results into a display shape. Schema: `{ id, label, icon, type, data }`. Supported types: table, cards, matrix, prose, custom.
- `collectionSummary` — reuse the approved Collection Reading or Step 3 summary; never synthesize a new narrative, pattern, gap, distinctive, or `highlight` for dashboard completeness.

**Open-value projection (critical):** Build the Values matrix from the mechanical union of the exact value labels in the approved per-site records. An uncatalogued value receives its own row/column; if it occurs for only one site, the display preserves that distinctiveness rather than absorbing it into a nearby category. For all other sites use `u` unless the upstream analysis explicitly established `i` or `a`. A normalized comparison to [CA-V], OUV, or another framework is a separate, explicitly requested view that displays the original term alongside the mapping.

**Location data is upstream:** copy only supplied or previously resolved and approved coordinates. If the user wants a map and coordinates are missing, perform location resolution as a separate conversational evidence step before generating the dashboard. Do not look up or infer coordinates while assembling `DATA`.

**Runtime compatibility:** `atar-runtime` and `data-contract.md` must accept dynamic value labels, `u` (not stated/unknown), optional `highlight`, and optional `themes`. If the installed runtime still requires eight fixed value categories, only `e/i/a`, a generated highlight, or a mandatory theme, update that runtime/contract; never remap or invent findings to satisfy the older schema.

### 3. Rendering through the InSites MCP App

Call `render_insites` with `approved: true` and the faithful approved `DATA` projection (`type: 'collection'`). Read `references/data-contract.md` for field shapes. The server validates the data and mounts pinned `atar-runtime` 0.3.8 in the MCP App. Do not emit a React shell, renderer, chart engine or model API call. The adapter sends questions and view context to this conversation using the MCP Apps host message channel. Answer here under the core epistemic rules and existing approval gate; do not advance a stage. Report validation or load failures and ask for the missing evidence instead of inventing content.

### 4. Tabs the runtime renders (what DATA powers each)

Fixed tabs from `DATA`: **Overview** (mechanical KPIs and distributions of already-approved fields + the approved `collectionSummary`) · **Map** (approved site coordinates only; Leaflet+OSM with a zero-network vector fallback) · **Values** (sites × exact, dynamically discovered value labels; `e`/`i`/`a`/`u` status) · **[Themes]** (shown only when approved `themes[]` are present). Then approved dynamic `tabs[]`, then an **AI Query** tab that sends its question and view context into this conversation.

Dynamic `tabs[]` (MA-RC Step-3 analysis results) — types `table` (Arguments), `matrix` (Gaps traffic-light), `custom` (Cross-Tabs), `cards` (Management Clusters), `prose`.

### 5. Final Checklist
1. **Output**: call `render_insites` with approved DATA; no surrounding prose on success. Explain errors in chat. Runtime pinned at 0.3.8.
2. **Data**: per §2 + the open-vocabulary projection contract (`type:'collection'`). Every exact and uncatalogued value is preserved. `themes[]` and `highlight` remain empty/omitted unless approved upstream. Values use `e`/`i`/`a`/`u`, and missing mention is `u`, not `a`.
3. **Language/RTL**: fields follow Language Policy; the runtime auto-detects Hebrew → RTL.
4. **Location**: project approved coordinates and provenance only. Missing coordinates remain an explicit gap until resolved upstream.

**Dataset Export (offer)**: after generating, offer the projected collection data as structured JSON (collection metadata + per-site objects + original/open-vocabulary labels + any optional mappings stored separately).

