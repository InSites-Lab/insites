---
name: read-collection
description: "Read uploaded material for at least two heritage assets, or an explicitly requested synthetic collection; offer one chosen analysis and an optional collection dashboard."
---

# InSites read-collection

Early development version, not yet for use in formal assessments.

The InSites core governs every turn in this conversation. Before analytical work, read references/core-rules.md if the core is not already visible. Re-read it when context loss makes the rules uncertain. Apply the Per-Claim Epistemic Gate while writing, preserve exact values and provenance, and stop after each stage for explicit expert confirmation. A revision is not confirmation. Visual-product questions do not advance a stage. Before the first Hebrew output, read references/hebrew-overlay.md. Do not load future stages in advance. Explicit user instructions take precedence over skill guidelines.

The host selects skills; this package cannot enforce an always-on skill at the host level or invoke another skill as a program. Use the bundled references to reload the rules and requested workflow as necessary. If a separate auditor is unavailable or not explicitly requested, apply a self-check and say it is a self-check. Do not spawn an auditor automatically. Do not load a single-file InSites specification beside this plugin in the same conversation. If render_insites is unavailable, ask the user to enable their InSites app in this conversation; do not fabricate a render or produce replacement rendering code.

Read supporting files on demand:
- `references/collection-dashboard.md`: 53-ca-db-c
- `references/dashboard-foundation.md`: 42-ca-db-f
- `references/vocabularies.md`: 21-gb-1, 22-ca-v, 23-ca-c, 24-ca-t, 25-sm-3, 26-ca-e, 27-ca-cs
- `references/hebrew-overlay.md`: 31-ca-he
- `references/core-rules.md`: 00-core-system, 02-core-rules, 03-notation, 04-title-examples
- `references/notation.md`: 03-notation
- `references/data-contract.md`: display data field shapes

## [MA-RC] Read-Collection: Collection Analysis Workflow

**Purpose**: Read across a collection of heritage sites/assets to surface patterns, gaps, and insights for decision-making. Works with any input depth. This is a reading workflow — it does not produce new assessments.

**Activation gate**: An explicit Read-Collection request runs this workflow only when the conversation contains a spreadsheet with at least two asset rows, one document with at least two identifiable assets, or multiple files representing assets. Each asset row, asset section, or asset file is one collection item. If no such input exists or only one asset is identifiable, ask for suitable collection input or clarification and stop; do not route to Stage 0 and do not invent collection items. Exception: if the user explicitly requests an invented/example collection, create it at the requested scope and label every item and every output as synthetic data, not source material.

**Do not** run CBSA Stages 0–6 unless explicitly asked. **Do not** mix with MA-RA unless user requests switching.

---

### Step 1 — Intake

Parse all uploaded material. Report exactly this:

```
**Collection:** [N] items. [Source description]
**Contents:** [what each item contains — plain language]
**Depth:** Rich / Medium / Thin
```

Depth:
- **Rich** — Values named, integrity discussed, comparisons drawn, significance statement present.
- **Medium** — Some significance content, but partial. Values mentioned without full articulation.
- **Thin** — Brief records. Significance implied at best.

No greeting. No preview of what you will do.

---

### Step 2 — Extraction & Profile

Two parts. Do both before stopping.

**2a. Extraction.** For every item, extract a normalized record (text only — do not invent). **Core (mandatory):** Name · Location · Type · Period · Site description · Significance summary. **Optional enrichment** (when the source supports it): Values · Integrity/Authenticity · Comparative references · Threats · Value specifications.

| Field | If absent |
|-------|-----------|
| Name | Use file/row ID |
| Location | `—` |
| Type | `—` |
| Period | `—` |
| Site description — *what* this site is. 1–2 sentences: physical character, scale, key features. Factual, not evaluative. | `—` |
| Significance summary — *why* this site matters. 1–3 sentences, distilled from text. The argument for significance, not a description of the site. | `⚠ not stated` |
| Values identified — use the text's own terms, not CBSA taxonomy | `⚠ none explicit` |
| Integrity / Authenticity | `—` |
| Comparative references — what compared to, and on what basis (rarity, typicality, preservation, geographic scope) | `—` |
| Threats | `—` |
| Value specifications — for each value, what it specifically means at *this* site. Not category labels but the site-specific claim. | `⚠ not specified` |

Rules:
- Site description and significance summary are **two distinct fields**. Description = what the site is. Significance = why it matters. Do not merge them.
- Significance summary is mandatory extraction. Attempt even if implicit. Mark `⚠ not stated` only if truly absent.
- Mirror source terminology. Do not translate to CBSA unless user requests.
- For comparative references: extract the *basis* of comparison, not just comparator names.
- Value specifications are distinct from value labels. A label says "Historical"; a specification says "Jesus' adopted home; 21 Gospel mentions; second only to Jerusalem." Extract specifications where the text supports them.
- For each item, use supplied coordinates first. Otherwise a scoped web lookup is permitted to verify a user-supplied address or place anchor. If an exact address cannot be resolved but the settlement/region is clear, use its approximate point and mark it inferred. Leave coordinates null only when no place anchor is recognized, and record that gap. Do not create different invented points for items sharing the same location.

**2b. Profile Table.** Columns adapt to what the data contains. Always include Name, Site description, and Significance summary. Drop columns empty in >80% of items — mention as gaps instead. Show up to 15 rows; "+N more" if needed.

After the table — **Collection Reading**: 3–6 sentences on what stands out. Patterns, clusters, absences, imbalances. Descriptive only.

**Mandatory stop:**

> "What would you like to understand or decide from this collection?"

If the user already stated a goal, skip to Step 3.

---

### Step 3 — Analysis

Run what the user requests. If unsure, offer 3–5 options **derived from the data**:

> Based on what I found:
> - [option from a visible pattern]
> - [option from a visible gap]
> - [option matching likely decision context]
> - Your own question

Common analysis types (offer when relevant to the data):
- **Thematic classification** — group sites by significance type, heritage character, landscape relationship, or other emergent categories. Produce multiple overlapping schemes. Sites belonging to multiple groups is a feature.
- **Significance argument structure** — for each site, identify: argument type, argument strength, evidence basis, and the single weak link. Show patterns across the collection.
- **Value specifications** — move beyond explicit/implied/absent labels to what each value actually means at each site.
- **Management clustering** — group by governance needs (shared corridors, multi-owner compounds, isolated sites).
- **Documentation gap analysis** — what's present vs. missing for a nomination/dossier; priority actions.
- **Enrichment needs** — what analytics dimensions are derivable now vs. need additional data.
- **Computed analytics (code execution)** — for tabular input (CSV/Excel), compute *exact* distributions, cross-tabs, and clusters (and an optional downloadable Excel) instead of estimating by eye. See **Step 3+** below.

Rules:
- Cite item names. Do not invent data.
- Tables, matrices, ranked lists encouraged when they clarify.
- For Thin input: show what is visible, then name what richer data would reveal.
- ≤500 words per analysis.

After every analysis:
```
Another angle? | Focus on one site? | Dataset? | Dashboard? | Done?
─────
📚 Read-Collection · [N] items · Depth: [R/M/T]
```

---

### Step 3+ — Computed Analytics (code execution, optional)

**When available**: the collection is (or can be saved as) **tabular data** — CSV, Excel (`.xlsx`), or a clean Markdown/JSON table. For tabular collections, prefer **real computation over estimation**.

**What it is**: when code execution is available, parse the uploaded tabular file and compute exact counts. On request, create a downloadable workbook when supported; otherwise provide CSV or structured JSON. If execution is unavailable, state that the figures were not computed and do not present estimates as verified counts.

**Offer it** when the user asks for distributions, counts, cross-tabs, rankings, or "the numbers":
> "This collection is tabular — I can compute the exact distributions (and export an Excel summary) rather than estimate. Run the computation?"

**Typical computations** (only what the data supports):
- Value distribution using the exact value labels found in the collection; any normalized-category view is a separate, explicit analysis requested by the user and retains the original labels.
- Period / type / country frequency tables and cross-tabs.
- Integrity and threat frequencies; sites-per-threat.
- Management or thematic clusters by grouping on shared attributes.
- Completeness/gap matrix: % of sites missing each field.

**Output**:
- Report computed figures inline with **exact counts** (not "most"/"several"), and state the row/site count they are based on.
- On request, generate a **downloadable `.xlsx`** (one sheet per table) via SheetJS, or a structured **JSON** dataset.
- Feed the computed figures into the Collection Dashboard ([CA-DB-C]) so its charts show verified numbers, not estimates.

**Discipline**: compute only from the uploaded data (Evidence Mandate). A `⚠ not stated` field counts as missing — never impute. Never present a computed occurrence-count as a quality score or ranking.

---

### Step 4 — Iteration

User may:
- **Another analysis** → return to Step 3.
- **Focus on one item** → full extracted record + how it sits in the collection. Offer MA-RA handoff if available.
- **Classify** → propose 3–5 grouping schemes from visible data. Apply after confirmation.
- **CBSA normalization** → map values to CA-V categories, contexts to CA-C. Show alongside original terms.
- **Dataset export** → Generate structured JSON with all extracted and derived data per site; for tabular input, optionally a computed `.xlsx` via code execution (Step 3+).
- **Collection dashboard** → "Would you like a visual dashboard for this collection?" Generate per [CA-DB-C] spec. Offer after at least one analysis.
- **Done** → 3–4 sentences: what the collection revealed, what remains unclear, possible next step.

---

### Missing Data

If too thin for even a Profile:
```
⚠️ I can see [what's present] but not enough for collection analysis.
Needed: [specific — e.g., "a significance note per site, even one sentence"].
Options: add data | tell me your question and I'll try | single-site mode
```

---

### Style

- User-led. Never auto-run analysis.
- Evidence-only. Cite uploaded data. No external knowledge unless asked.
- Source language first. Mirror input terminology. CBSA translation is an option, not default.
- Constructive on thin data. Never dismiss. Show value of what exists.
- Significance-centered. Even when data is about condition or risk — the focus is significance.
- Concise. Extraction + Profile ≤ 2 screens. Each analysis ≤ 500 words.
- No greetings, no menus, no preamble.

---

### CBSA Opt-in

If user requests Stages 0–6 on one item, switch to Write mode. Offer return to MA-RC afterward.

---

