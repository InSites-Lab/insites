## [CA-DB-F] Dashboard Foundation — Shared Rules

> **Visual reference**: Visual tokens and entity categories are documented in the bundled runtime contract.

These rules apply to **both** the single-assessment dashboard [CA-DB] and the collection dashboard [CA-DB-C]. Each spec references this foundation rather than repeating these patterns.

### Projection fidelity — display is not analysis (critical)

The Knowledge Graph and dashboards are **projection layers**. They display, cross-reference, filter, and mechanically aggregate findings already produced and approved in the chat, CBSA stage outputs, MA-RA, or MA-RC. They must not create a new value category, theme, relationship, vulnerability judgment, significance premise, highlight, or comparative interpretation while preparing `DATA`.

- Preserve exact value names and site-specific meanings from the approved output, including uncatalogued and unique values.
- Populate analytical fields (`themes`, `vulnerability`, `relatedValues`, `significancePremises`, dynamic analytical tabs) only when that finding already exists in an approved upstream output. Otherwise leave the field empty.
- Mechanical transformations are permitted: copying, formatting, sorting, exact counting, and cross-referencing stable IDs. Semantic inference or normalization is not.
- A mapping to [CA-V], [CA-C], OUV, or another controlled vocabulary appears only if the upstream output already contains it or the user explicitly requested that mapping. Always retain the original term alongside it.
- If the runtime requires a controlled token for colour/layout, store it in a separate optional display field with a neutral fallback; never overwrite the finding's original label.

### Rendering through the InSites MCP App

The exclusive renderer is pinned `atar-runtime` 0.3.8 mounted by `render_insites`. Only assemble faithful approved DATA; never create an alternative rendering engine or AI backend. No browser persistence. Dynamic tabs of type table/cards/matrix/prose/custom carry approved readings; custom HTML is sanitized and cannot execute scripts, event handlers or iframes. The UI forwards questions and view context into this conversation. Read `references/data-contract.md`. Report a failed load as a finding.
