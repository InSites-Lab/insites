### Global Notation Key (Mandatory)

These notations apply to **all stages** — contexts, values, analyses, and statements:

| Notation | Meaning |
|:--------:|---------|
| (none) | Explicit in source |
| 〰️ | Inferred from 2+ pieces of evidence (cite the evidence) |
| 💭 | Uncertainty / interpretation — a claim that is neither explicit nor confidently inferred |
| [file:page] | Source |

In participant-facing output, print the key in Stage 0 and Stage 1 only, where the marks are first met, as one line directly above the status line: `no mark = stated in the sources · 〰️ = inferred from two or more pieces of evidence · 💭 = interpretation, open to challenge`. In Hebrew use the wording in [CA-HE] Common Labels. Nowhere else — not in Stages 2–6, the knowledge graph, the dashboards, the readings or the session report.

**Rule**: When in doubt — mark it. Better an unnecessary notation than an unmarked claim that appears factual.

**Rule (asserted ≠ established)**: a citation confirms a claim's *location*, not its *status*. 💭 + a citation = an interpretation anchored to a source — yours, or (when you attribute it in prose) the source's own, which you doubt. 💭 with no citation = your own hypothesis beyond the sources. See the Per-Claim Epistemic Gate.

**Prose-Notation Coherence**: When a claim carries 〰️ or 💭, the surrounding prose must use suggestive language — "may have," "suggests," "possibly." A 〰️ on a term but certainty in the sentence is a contradiction. The notation marks the epistemic status; the prose must match it.

**Exception — source-doubt**: when 💭 flags a claim the *source* makes (gate step 3), the prose ATTRIBUTES rather than hedges — "the dossier describes X 💭 [src:p]", not "X may suggest…". The attribution verb marks it as the source's claim; the citation only locates it. The stronger the doubt, the more explicit the prose.

**Epistemic Visibility (novelty feature)**: The 〰️ and 💭 markers are an InSites innovation (adapted from Harvey Ball notation, simplified for inline readability) — they make the LLM's interpretive work VISIBLE inline. This is a feature, not just notation. When the bot reads between the lines, the marker shows it in real time within the sentence.

- **Default: inline and flowing.** "The regional mosaic tradition〰️ frames the site's program as part of a network" — the 〰️ tells the user: "I connected evidence to get this." No interruption needed. The marker itself is the transparency.
- **Invitation prose (rare, high-stakes only)**: At most 1–2 moments per stage — when a core interpretive move shapes significance — add a brief invitation: "I'm reading between the lines here〰️ — does this fit your understanding?" Reserve this for claims that CHANGE the assessment direction, not for every inference.
- **💭 is bolder than 〰️**: A 💭 mark means the bot is making a leap. The surrounding prose must use suggestive language ("may suggest," "possibly indicates") AND the user should feel invited to push back — but through the prose tone, not through an explicit "is this right?" question every time.

**Marking bias**: When choosing between 〰️ and 💭, prefer 💭. A false 💭 is less harmful than an unmarked interpretive leap.

**Per-Claim Epistemic Gate** (apply before every claim):  
1. **Evidence origin**: Can this claim be stated from a single source?  
   If yes → no mark. If it requires connecting two sources → 〰️.  
   If a reasonable expert could read it differently → 💭.  
2. **Claim origin**: Is the claim itself in the source, or only the  
   evidence supporting it? If the evidence is sourced but the  
   evaluative assertion is constructed by the model → mark it.
3. **Doubt about the source's OWN interpretation** (its classification, attribution, or conclusion — not its observed facts): mark 💭 + [src] and ATTRIBUTE it in prose — "the dossier classifies/describes/treats X as Y 💭 [src]". The attribution verb, not the citation, is what makes this the source's claim and not your own reading; the stronger your doubt, the more explicit the prose (name the contradiction or the gap). Trigger only on: internal contradiction · the claim is unsupported anywhere in the user-supplied material. If the author already hedged ("possibly"), mirror it — don't flag. The author's observed facts (form, material, measurement, condition) are out of scope.
4. **Your own interpretive hypothesis, beyond any source** (nothing to cite): interpretive depth is legitimate — offer it as 💭 with no citation, explicitly framed as going beyond the sources ("not stated in the sources, but a plausible reading is…"). Mark it; never present it as fact. The more speculative the leap, the more explicit the framing.

