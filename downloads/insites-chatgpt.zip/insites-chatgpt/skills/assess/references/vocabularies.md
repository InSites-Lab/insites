## [GB-1] CBSA General Guidelines

CBSA is a holistic, values-based heritage assessment approach that integrates physical and non-physical aspects across multiple contexts. The **Context Effect** is an analytical proposition to be tested where context relationships are relevant — see Critical Operating Rules for the operational definition. It is an interpretive/value-attribution mechanism, not a causal description of real-world change. Its two directions are evaluated independently; two-way and one-way findings, and a "no supported effect identified" outcome, are all valid. The stages structure the thinking process, not a rigid formula.

---



## [CA-V] Value Types and Definitions

**Open vocabulary (critical):** This list is a reference vocabulary, not a closed taxonomy. Preserve every source-stated, community-stated, site-specific, or emergent value in its original wording. Use a category below only when the stage output already made that mapping or when the user explicitly requests CBSA normalization. Never replace an uncatalogued value with the nearest category, `Other`, or a generic label. A unique value that does not map to this list remains a valid value and may itself be a finding.

Use plain language in outputs; avoid acronyms. When relevant, adapt sub-categories. When showing both layers, display `Original/site-specific value` first and `Optional CBSA mapping` second.

- **Historical Value**: Connection to past events, periods, people, or functions.
- **Aesthetic Value**: Design, style, artistry, materials, setting.
- **Social Value**: Community connection, use, cultural practices.
- **Technological Value**: Construction methods or technical innovation embodied in fabric or process.
  - *In archaeology*: construction techniques, material sourcing (quarry origin, trade routes), craft specialization evidence
- **Symbolic Value**: Represents identity, belief, collective meaning, emblematic forms.
- **Landscape Value**: Contribution to wider visual / spatial / environmental setting.
  - *In archaeology*: settlement patterns, inter-site relationships, viewshed, route networks
- **Scientific Value**: Potential for research, archaeological or archival study.
  - *Research potential*: unexcavated deposits, intact stratigraphy, sealed contexts
  - *Typological value*: representative or diagnostic of a type, period, or regional tradition
  - *Methodological value*: site demonstrates or advanced a research technique or conservation method
- **Documentary / Archival Value**: Quality of recording, publication history, accessibility of research archive. A well-documented site carries value *through* its documentation — the record itself is a heritage asset, especially when physical remains have been partially removed by excavation.
  - *Preservation-as-archive*: Intact deposits are themselves a primary record — future methods may extract more than today's. This value diminishes upon excavation, even when well-documented.
- **Spiritual Value**: Religious or ritual significance.
- **Environmental Value**: Ecological connection, biodiversity, natural features.
- **Urban Value**: Relationship to urban form, streetscape, spatial coherence.
- **Mystery and Enigma Value**: Elements of uncertain origin/meaning that provoke interpretation and cultural curiosity.
- **Functional Value**: Ongoing or adapted practical use that sustains relevance.
- **Educational Value**: Supports learning, interpretation, heritage awareness.

---



## [CA-C] Context Types

**Mandatory constraint**: Every selected context must be supported by evidence and linked to values.

- **Geographic Context** — Location, climate, topography, accessibility
- **Landscape Context** — Terrain, views, vistas, natural features, visual setting
- **Urban Context** — Street grid, density, neighbourhood character, built fabric
- **Historical Context** — Periods, events, continuity, macro-processes
- **Social Context** — Community, use patterns, identity, gathering practices
- **Political Context** — Governance, regulation, power structures, land tenure
- **Technological Context** — Tools, methods, craft traditions, technical systems
- **Environmental Context** — Ecology, resources, sustainability, climate
- **Intangible Heritage** — Traditions, stories, beliefs, oral histories
- **Thematic Context** — Shared narratives, typologies, regional themes
- **Archaeological Context** — Excavation history, research campaigns, methodological approaches, site formation processes. How the site was investigated shapes what is known and what remains uncertain.

---



## [CA-T] Change Types: Operational Theory

Changes at a site affect different values differently. Understanding which type of change occurred helps explain why certain values strengthen or weaken.

### Change Type Definitions

**Fabric Changes** (material, structure, form) — Primarily affects: historical, aesthetic, scientific values. Loss of original materials reduces material authenticity. *E.g., "Original ashlar masonry replaced with modern concrete" → loss of aesthetic value.*

**Infrastructure Changes** (access, services, technical systems) — Primarily affects: functional value and practical experience. Different accessibility reshapes how the site is used. *E.g., "Access road built to remote site" → social value altered but preserved.*

**Use Changes** (original function → adaptation) — Primarily affects: social, spiritual, functional values. Site may be preserved materially but lose cultural practice. *E.g., "Church converted to museum" → loss of spiritual and social value despite structural integrity.*

**Setting Changes** (surrounding context, visual relationships) — Primarily affects: urban, landscape, symbolic values. Site visually or culturally disconnected from original context. *E.g., "Ancient temple surrounded by modern development" → loss of landscape and symbolic value.*

**Interpretation Changes** (how site is understood, narrated) — Primarily affects: all value types, depending on narrative. Cultural significance shifts even if physical form unchanged. *E.g., "History reframed to centre local narrative instead of colonial one" → changes social and symbolic value.*

### Application in the Nara Grid

Use change type prefixes in the integrity assessment to clarify which aspect of the site changed and how it affects value expression. Example: "(fabric) Original materials lost but form remains legible" versus "(use) Structure preserved materially but social practice ceased."

---



## [SM-3] Integrity and Nara Grid: Theory and Application

### Defining Integrity in CBSA

Integrity measures how much of the original form, material, use, setting, or interpretation of a site has survived intact. In CBSA, integrity is not "preserve everything perfectly" — it is about managing selective change while maintaining the values that make the site culturally significant.

A site can have:
- **High material integrity** (original materials present) but **low use integrity** (no longer in use)
- **High form integrity** (original design legible) but **low setting integrity** (surrounded by new development)

The heritage assessment question: "Which integrities matter most for this site's identified values?"

### Nara Grid Assessment

See Stage 3 for Nara Grid table structure, template columns, and assessment rules. Key principle: rate each aspect independently (high / medium / low / lost) — high integrity in one aspect does not require high integrity in others.

---


## [CA-E] Examples and Phrasing Aids

**Comparative Claims:** "Represents the… / Rare for… / Earliest known example of…"

**Implication Sentence Templates:** "Reduces legibility of… / Diminishes landmark presence of… / Obscures original volume of… / Breaks continuity of… / Alters spatial hierarchy of…"

**Integrity Phrasings:** "Later additions partially obscure… / Original profile remains legible despite…"

---



## [CA-CS] Comparative Significance Criteria

Use these criteria in Stage 4 (comparison with other assets) and Stage 5 (significance statement) to support professional judgments.

- **Period**: Represents a significant era or phase in history.
- **Rarity**: Few similar examples exist locally, regionally, or nationally.
- **Documentation**: Well-documented in archives, plans, photographs, or oral histories.
- **Ensemble Connection**: Contributes to a group of related sites or features.
- **Condition**: Degree to which original fabric or setting is preserved.
- **Selectivity/Diversity**: Contributes to diversity of heritage types represented.
- **Research Potential**: Holds potential for further scholarly, scientific, or archaeological study.

> *Archaeological specialist layer — `[CA-EV]` evidence-type epistemology, three-state integrity, the excavation change-type, and excavation-documentation prompts — is extracted to `cbsa-archaeology-layer.md`. Load it only in archaeology deployments; it is not part of this general (built-heritage-first) build.*

---

