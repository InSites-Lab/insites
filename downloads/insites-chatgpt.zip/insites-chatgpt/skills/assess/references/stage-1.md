## Stage 1️⃣ Description and Contexts

**💡 Brief** — see [CSR]. Anchor in Stage 0 findings.

**Link to Previous Stage**: Before output, note 1-2 items from Stage 0 on which the analysis builds.

---

### 🔍 1.1 Site Description

Write a description of under 260 words. Dense, not padded. At the end of stage 1, offer expansion.

**Include**:
- Location and setting
- Who built it and when
- What it originally served as
- How it changed over time

**Physical information — integrate within the description, not as a separate section**:
- Materials and construction methods — when describing the construction
- Form and architectural features — when describing the structure
- Current physical condition — when describing the present

**Structure**:
- Opening: Where the place is located and its setting
- Body: Development in chronological order — changes in use, structure, ownership, setting
- When a connection exists between a change and a broader context — note it

---

### 🕰 1.2 Timeline and Periods

Include if there are 2 or more dated or period-associated events. If not — write "Insufficient information" and specify what is missing.

| Date / Period / Layer | Change in Use | Change in Structure | Notes |
| --- | --- | --- | --- |

Include every dated or period-associated event from the sources. Do not skip.

---

### 🌐 1.3 Contexts

**Source**: See [CA-C] for full list, [GB-1] for context effect.

**Context ≠ Value**:
- Context = lens, framework, field of examination (Stage 1)
- Value = cultural significance identified and classified in the assessment (Stage 2)
- Contexts are descriptive frameworks. Describe the framework and test whether a context effect is supported. Do not evaluate significance — that is Stage 2's job. If you find yourself writing "this is significant because" or "this demonstrates," you are doing Stage 2 work prematurely.

**Starting Point**: Geographic, landscape, urban, historical, social, political, technological, environmental, intangible heritage, thematic.

**But also** (mark these — this is where epistemic notation activates):
- Contexts that emerge from the unique description of the place — even if not in the dictionary (〰️)
- Reading between the lines — what the original author may not have noticed (💭)
- Surprising convergences of details that create meaning (〰️)

**For each context, write 1-3 sentences**:
1. Site-specific description — not a general definition
2. Context-Effect Test (report a finding when at least one direction is supported; state "no supported effect identified" only when that outcome is analytically important):
  - Assess how the context frames the reading of the site's features (`context → asset`).
  - Separately assess whether recognizing the site's significance reframes that same context (`asset → context`).
  - Report only the supported direction or directions. A one-way finding is complete; a two-way finding is not preferred over it. If neither direction is supported, do not manufacture a second sentence. State "no supported effect identified" only when that outcome is analytically important.
  - **Outward dimension**: When source material identifies connections to external sites, traditions, or themes, assess whether the context effect extends beyond the asset. State only the supported direction or directions; do not presume that a connected entity gains heritage value from the association. Only source-stated or inferable (〰️) connections qualify. E.g., when both directions are supported: "The regional mosaic tradition frames Huqoq's program as part of a network; Huqoq's exceptional quality reframes the significance of related sites like Wadi Hamam within the network."
  - ⚠ Do not use causal phrasing ("caused", "led to", "created change")
  - Context-effect here describes the FRAMING relationship (how context shapes what we notice), not the significance CLAIM itself (that's Stage 2).
3. `🧭 Planning:` — one sentence on what to protect, interpret, or coordinate, including regional implications when evidence supports them. Omit if no actionable implication exists.

**Output Format — clean and flowing**:

```
🌐 Contexts

Historical — The structure was erected in the Mamluk period and served as a caravanserai along a major trade route. [A:3]

Social — Functioned as a communal gathering point for regional trade networks and seasonal markets. [B:7]

Political〰️ — Changes in ownership reflect successive shifts in regional governance. [A:5, B:12]
```

**Notation**: See Global Notation Key in Global Controls.

**Output shaping (critical)**:
- Lead each context with its emoji marker (see Engagement & Visual Clarity) + type label.
- **40–60 words per context.** First sentence = site-specific framing, not a generic definition. A following sentence reports a context-effect finding only when supported; it may be two-way or one-way. "No supported effect identified" may be stated when that outcome is analytically important. Include 🧭 Planning sentence only if warranted — it counts toward the word budget.
- Write effect directions as plain sentences; never print "context → asset" or "asset → context".
- **Cap: 5 contexts.** Select by evidence weight and analytical contribution — the contexts that most distinctly frame the site's significance. A 6th only if evidence strongly demands it and its analytical contribution is non-redundant.
- Order by analytical contribution, not alphabetically.

---

### ⚠ Critical Gap

Display this section **only** if a significant gap was discovered that was not identified in Stage 0 and could affect subsequent analysis.

---
### 💡 Reflection
One focused question that challenges the user to think differently — a genuine tension where two reasonable expert positions exist, based on this specific content.

Continue to Stage 2, or add/correct anything first?

---

## Internal Instructions (the bot executes, does not display to user)

**Before every output, verify**:
- [ ] Physical information (materials, condition, form) is integrated in the description
- [ ] All dated/period-associated events appear in the timeline
- [ ] Contexts describe examination frameworks — not values or significances
- [ ] Contexts are correctly notated: no notation / 〰️ / 💭
- [ ] No causal phrasing used
- [ ] Sources appear briefly [file:page] at the end of each context
- [ ] 💭 (if present) proposes a context, not a value
- [ ] Looked for readings the sources do not state, and for interpretive leaps left unmarked; everything found is marked 💭. Finding none is a valid result.

---

```
─────
1️⃣ Stage 1/6 done · Next: Stage 2 Values
```


---

> **Plugin edition — at the point of sending this stage:** this turn carries this one stage only. Apply the Per-Claim Epistemic Gate and the Global Notation Key from the core to every claim. End with the Stage Closing Mechanism and the status line, then STOP until the user confirms. A revision is not a confirmation (Revision Stop Rule).
