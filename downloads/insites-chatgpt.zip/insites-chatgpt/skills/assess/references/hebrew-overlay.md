## [CA-HE] Hebrew Output Overlay

### Rendering Directive
When the user's language is Hebrew, render ALL structural elements using the maps below. Prose remains natural Hebrew. Every visible heading, status line, list item, label, tab name, offer, and closing question must be Hebrew and begin with Hebrew. Do not mix English structural labels into Hebrew output. Technical identifiers may remain English only in code/schema or in parentheses after the Hebrew display name.
- HTML artifacts: add `dir="rtl" lang="he"` to the root element. Add `body { direction: rtl; text-align: right; }` to CSS.
- **Tables in Hebrew (critical)**: Prepend the Unicode RIGHT-TO-LEFT MARK character (‏ U+200F) at the start of every table cell containing Hebrew text. This forces RTL text direction inside markdown table cells. Example: `| ‏ממוקם על חופה המערבי | ‏✓ | ‏מיקום וסביבה |`. Also reverse column order so the rightmost column is the first header for RTL reading order.
- **Sub-section numbering**: Use simple numbers (1, 2, 3) not decimals (1.0, 2.0, 3.0) in Hebrew output. Write "1 תיאור האתר" not "1.0 תיאור האתר".
- Do not translate methodology concepts that are used as-is in Hebrew professional discourse: CBSA, Context Effect (אפקט-הקשר), Human-in-the-Loop, CSR, DQR.
- Fixed Hebrew display names: מפרט, קריאת הערכה, קריאת אוסף, גרף ידע, דשבורד, נארה גריד, דוח, מצב כתיבה.

### Stage Title Map
| English | עברית |
|---|---|
| Stage 0: Preliminary Review | שלב 0: בדיקת מידע מקדימה |
| Stage 1: Contexts | שלב 1: תיאור והקשרים |
| Stage 2: Values | שלב 2: ערכים |
| Stage 3: Authenticity & Integrity | שלב 3: אותנטיות ושלמות |
| Stage 4: Comparative Analysis | שלב 4: ניתוח השוואתי |
| Stage 5: Cultural Significance Statement | שלב 5: הצהרת משמעות תרבותית |
| Stage 6: Quality Check & Summary | שלב 6: בקרת איכות וסיכום |

### Table Header Maps
**Stage 0 checklist**: קטגוריה / סטטוס / הערה
**Stage 0 documentation profile**: מקור / דרגה / סוג / מגבלות
**Stage 1 timeline**: תיארוך / שינוי בשימוש / שינוי במבנה / הערות
**Stage 2 values**: מאפיין / ערך/ים משויכים / משמעות באתר / השלכה 🔑
**Stage 3 Nara Grid**: היבט / תיאור / ביטוי ערכים / שלמות
**Stage 6 quick boosts**: בעיה / שיפור שיעשה הבדל
**MA-RA coverage scan**: רכיב CBSA / קיים? / עומק / הערות
**Collection reading**: שם / מיקום / סוג / תקופה / תיאור / תקציר משמעות / ערכים / שלמות·אותנטיות / השוואות / איומים

### Common Labels
**Integrity ratings**: גבוהה / בינונית / נמוכה / אבודה
**Evidence notation**: no mark = מפורש במקור, 〰️ = מוסק מ-2+ ראיות, 💭 = פרשנות (הסקה רחוקה יותר — הפרוז חייב להשתמש בשפה מסוייגת: "ייתכן", "מרמז", "אפשר ש-")
**Citation format**: [קובץ:עמוד] (not [file:page])
**Stage closing**: "להמשיך לשלב N?" (not "Continue to Stage N?")
**Reflection labels**: "לחשיבה" / "לפני שממשיכים"
**Post-assessment tools**: גרף ידע / דשבורד / קריאת הערכה / קריאת אוסף
**Standalone specification**: מפרט עצמאי

**Status line**: `─────` then `[icon] שלב N/6 הושלם · הבא: שלב N+1 [שם]`
**Fixed strings**: 🧭 לתכנון: · ⚠️ ממשיכים עם מידע חסר: · ⚠ ציר הזמן חלקי · ⚠ ייתכן שהמקורות הייעודיים לנכס חלקיים · "לא נמצאו אתרים להשוואה בחומר שהועלה."
**Source tiers**: 1 תיעוד שדה ראשוני · 2 סינתזה מחקרית · 3 מסמך מורשת/ניהול · 4 סקר/מצאי · 5 מקור משני
**Source scope**: ייעודי לנכס · רקע כללי
**Change types**: (חומר) (שימוש) (סביבה) (תשתית) (פרשנות)

### Entity Types for KG
Keep the canonical English [CA-EC] `type` tokens inside JSON. The runtime translates their visible labels to: מקום, מבנה, אלמנט אדריכלי, דמות, אירוע, סיפור/נרטיב, ערך תרבותי, תופעה טבעית, יצירת אמנות/ממצא, מסורת/מנהג, קבוצה חברתית, תקופה היסטורית, דת/אמונה, זיכרון קולקטיבי, נכס מורשת.

### Value Type Labels
היסטורי, אסתטי, חברתי, טכנולוגי, סמלי, נופי, מדעי, רוחני, סביבתי, אורבני, תיעודי, חינוכי
אניגמה-מסתורין

These are display translations for explicitly approved mappings, not a closed list of value-node labels. Site-specific and uncatalogued value labels remain unchanged.

---

