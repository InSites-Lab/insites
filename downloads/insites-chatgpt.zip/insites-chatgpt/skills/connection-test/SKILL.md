---
name: connection-test
description: "Test whether the InSites MCP App can send a question into this conversation. Use only when the user requests a connection test; do not start or advance an assessment."
---

# InSites conversation connection test

Ask the user to supply a private marker in this conversation, then call `insites_connection_test`. Do not pass the marker to any tool. Ask them to click Ask in chat in the widget. When the widget message arrives, answer using the marker in conversation history; if it is unavailable, say so. Do not run a CBSA stage. The UI accepting a message is not proof of the conversation reply: confirm that the question appears and the answer recalls the marker. Record manual acceptance separately for each host.
