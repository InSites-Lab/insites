---
name: stage-spec
description: "Create a standalone specification derived from a requested InSites stage without executing that stage."
---

# InSites stage-spec

Early development version, not yet for use in formal assessments.

The InSites core governs every turn in this conversation. Before analytical work, read references/core-rules.md if the core is not already visible. Re-read it when context loss makes the rules uncertain. Apply the Per-Claim Epistemic Gate while writing, preserve exact values and provenance, and stop after each stage for explicit expert confirmation. A revision is not confirmation. Visual-product questions do not advance a stage. Before the first Hebrew output, read references/hebrew-overlay.md. Do not load future stages in advance. Explicit user instructions take precedence over skill guidelines.

The host selects skills; this package cannot enforce an always-on skill at the host level or invoke another skill as a program. Use the bundled references to reload the rules and requested workflow as necessary. If a separate auditor is unavailable or not explicitly requested, apply a self-check and say it is a self-check. Do not spawn an auditor automatically. Do not load a single-file InSites specification beside this plugin in the same conversation. If render_insites is unavailable, ask the user to enable their InSites app in this conversation; do not fabricate a render or produce replacement rendering code.

Read supporting files on demand:
- `references/notation.md`: 03-notation
- `references/stage-0.md`: 10-stage-0; read only for the requested stage
- `references/stage-1.md`: 11-stage-1; read only for the requested stage
- `references/stage-2.md`: 12-stage-2; read only for the requested stage
- `references/stage-3.md`: 13-stage-3; read only for the requested stage
- `references/stage-4.md`: 14-stage-4; read only for the requested stage
- `references/stage-5.md`: 15-stage-5; read only for the requested stage
- `references/stage-6.md`: 16-stage-6; read only for the requested stage
- `references/vocabularies.md`: 21-gb-1, 22-ca-v, 23-ca-c, 24-ca-t, 25-sm-3, 26-ca-e, 27-ca-cs
- `references/hebrew-overlay.md`: 31-ca-he
- `references/core-rules.md`: 00-core-system, 02-core-rules, 03-notation, 04-title-examples
- `references/data-contract.md`: display data field shapes

### Standalone Specification Command

`spec` / `stage specification` / `מפרט` derives a standalone agent specification from the active stage; a supplied stage number 0–6 overrides the active stage. A suffix such as `for use in...` / `לשימוש ב…` permits conservative adaptation only: replace the subject, terminology, and required input, but add no stages, criteria, quantities, sources, methods, or controls without an anchor in the source stage. Add only the minimal wrapper needed for independent operation, include the full epistemic-marking rules, and convert dependencies on earlier stages into explicit required inputs. Preserve the source stage's next-step text when present so participants can see how the original workflow behaves.

If the requested adaptation requires a substantive new method, ask whether to create an expanded adaptation. Before delivery, silently compare the specification with the source stage and remove any unsupported instruction. Do not run the stage. Output in the user's language; a Hebrew command produces a fully Hebrew specification under [CA-HE]. Deliver editable Markdown text, and a downloadable Markdown file when file creation is available. After a revision, offer the revised file.

