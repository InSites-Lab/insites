---
name: knowledge-graph
description: "Create an InSites knowledge graph from approved findings on explicit request. Use render_insites; introduce no new analysis."
---

# InSites knowledge-graph

Early development version, not yet for use in formal assessments.

The InSites core governs every turn in this conversation. Before analytical work, read references/core-rules.md if the core is not already visible. Re-read it when context loss makes the rules uncertain. Apply the Per-Claim Epistemic Gate while writing, preserve exact values and provenance, and stop after each stage for explicit expert confirmation. A revision is not confirmation. Visual-product questions do not advance a stage. Before the first Hebrew output, read references/hebrew-overlay.md. Do not load future stages in advance. Explicit user instructions take precedence over skill guidelines.

The host selects skills; this package cannot enforce an always-on skill at the host level or invoke another skill as a program. Use the bundled references to reload the rules and requested workflow as necessary. If a separate auditor is unavailable or not explicitly requested, apply a self-check and say it is a self-check. Do not spawn an auditor automatically. Do not load a single-file InSites specification beside this plugin in the same conversation. If render_insites is unavailable, ask the user to enable their InSites app in this conversation; do not fabricate a render or produce replacement rendering code.

Read supporting files on demand:
- `references/entity-categories.md`: 29-ca-ec
- `references/dashboard-foundation.md`: 42-ca-db-f
- `references/notation.md`: 03-notation
- `references/continuity.md`: 30-continuity
- `references/hebrew-overlay.md`: 31-ca-he
- `references/core-rules.md`: 00-core-system, 02-core-rules, 03-notation, 04-title-examples
- `references/data-contract.md`: display data field shapes

## [CA-KG] Knowledge Graph — CBSA Integration

Generate an interactive Knowledge Graph artifact when the user explicitly requests a Knowledge Graph ("kg", "knowledge graph", "create kg").

> **Visual reference**: Visual tokens and entity categories are documented in the bundled runtime contract.
>
> **Rendering**: Use `render_insites` after approval. The pinned runtime owns the graph; the adapter delivers questions into this conversation.

### 1. Trigger and Rendering Enforcement

- Execute only on an explicit Knowledge Graph request.
- Call `render_insites`; no surrounding prose is required on success. Explain tool errors in chat.
- Do not generate an alternative renderer or one-off model call.

### 2. CBSA Data Projection → DATA

1. Re-read the approved stage outputs (contexts, timeline, values, comparisons). Project only findings already present there; do not conduct a new analytical pass while building the graph.
2. List candidate nodes (target 10–15, maximum 20) in this priority order:
   - **Value-bearing entities** central to Stage 2 (the things that carry identified values)
   - **Key places/structures** and **major events** (the central heritage subject and temporal anchors)
   - **Context anchors** (geographic, social, political entities that shape significance)
   - **Social actors** (individuals, groups, communities relevant to the asset)
   - **Cultural Value nodes required to represent the approved findings**, preserving exact site-specific or uncatalogued value names. Never silently drop a unique value to satisfy the target count; if the graph would exceed 20 nodes, ask whether to generate an expanded graph or a user-approved focused view.
3. Capture only relationships already stated in approved outputs, using concise verbs (`located_in`, `expresses_value`, `part_of`, `commemorates`, `influenced_by`, `supports`, etc.). Do not infer a new edge during graph generation.
4. Drop duplicate nodes only. Prefer connected nodes, but never invent an edge or drop an approved uncatalogued value merely to avoid an orphan or because it lacks a [CA-V] mapping.
5. Assign each node a `type` from the [CA-EC] entity categories. Default to the closest existing category. A new type may be introduced only when a node genuinely falls outside all 15 categories and forcing a match would misrepresent its heritage role — in that case, name the new type clearly and add it to the colour map.
6. **Preserve epistemic status (mandatory)** — Copy each node/claim's approved epistemic status from the upstream output. Do not reclassify it in the graph layer. For `inferred`/`interpretive` nodes, copy or compress the existing rationale into `epistemic_note` (≤15 words). If no upstream status exists, use `unlabeled`; do not decide the status inside the visualization layer.

### 3. DATA Schema (strict)

⚠ Apply Language Policy to all KG fields.

```json
{
  "nodes": [
    {
      "id": "unique_id",
      "name": "Display Name",
      "type": "Entity Type",
      "meaning": "Optional concise approved description of its heritage role",
      "value_label": "Optional exact value name from the approved output",
      "mapped_value_category": "Optional [CA-V] or other taxonomy mapping only when upstream/requested",
      "epistemic": "sourced | inferred | interpretive | unlabeled",
      "epistemic_note": "Optional copied upstream rationale: <=15 words"
    }
  ],
  "edges": [
    { "source": "source_id", "target": "target_id", "label": "relationship_verb" }
  ]
}
```

**Rules**:
- `type` must use English tokens from [CA-EC] for colour mapping (the renderer automatically translates to display labels when needed).
- `meaning` is an optional concise copy or light compression of an approved, site-specific description. Do not compose a new heritage role in the graph layer. Follow the Language Policy.
- Optional `value_label` preserves the exact source/site-specific value name, including uncatalogued values. `mapped_value_category` is separate and appears only when a mapping was already approved or explicitly requested.
- Edges use lowercase verbs; keep total edges ≤ 25.
- `epistemic` copies the model's claim-level self-assessment already produced upstream: `sourced`, `inferred` (〰️), or `interpretive` (💭). If the upstream claim was not assessed, use `unlabeled`; never convert a missing label to `sourced`. Copy an existing `epistemic_note` for non-sourced claims when available. Surface it in the Info tab and review list only — never on the node glyph.

Send the projected graph as the tool's `data` argument (`type: 'kg'`). See the bundled data contract. RTL is detected by the runtime.

### 4. Rendering through the InSites MCP App

Call `render_insites` with `approved: true` and the faithful approved `DATA` projection (`type: 'kg'`). Read `references/data-contract.md` for field shapes. The server validates the data and mounts pinned `atar-runtime` 0.3.8 in the MCP App. Do not emit a React shell, renderer, chart engine or model API call. The adapter sends questions and view context to this conversation using the MCP Apps host message channel. Answer here under the core epistemic rules and existing approval gate; do not advance a stage. Report validation or load failures and ask for the missing evidence instead of inventing content.

### 5. Final Checklist

1. **Counts**: target 10–15 nodes (≤20) and ≤25 edges. Preserve every approved distinct value; if that exceeds the display target, ask for an expanded graph or a user-approved focus. Do not invent edges to eliminate orphans.
2. **Fields**: every node has `id`, `name`, and `type` (English [CA-EC] display token); `meaning` is optional approved text. Value nodes preserve exact `value_label`; any controlled-vocabulary mapping is separate and optional. Edges use `source`/`target` + a lowercase verb copied from approved findings.
3. **Epistemic**: every node copies its upstream status or uses `unlabeled`; missing status never defaults to `sourced`. Copy a non-sourced `epistemic_note` when it exists upstream. Per §2 / §3.
4. **Output**: the §4 shell only (only `DATA` replaced); no surrounding prose; `RUNTIME_URL` pinned `@0.3.8`.
5. **Language / RTL**: all fields follow Language Policy; the runtime auto-detects Hebrew → RTL (no manual `dir`).

---

**After KG**: Offer to highlight one supported context-effect relation. If accepted: 2 sentences max; describe only the direction or directions present in the approved graph. A single direction is complete. No theory preamble.

**Review interpretive entities (HITL)**: When the graph contains any `interpretive` (💭) entities, follow the artifact with a ≤2-sentence offer — "This graph has N interpretive (💭) entities: readings beyond your sources (see '💭 Entities to review' in the Analytics tab). Want to confirm, rename, reject, or cite-and-promote any?" On the user's reply, rename or remove the entity, or promote it to `sourced` when evidence is cited, then offer to regenerate the KG. Skip this offer when N = 0.

---

